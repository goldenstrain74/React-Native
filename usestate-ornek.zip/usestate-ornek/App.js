import { Text, View, StyleSheet, Button } from 'react-native';
import React, { useState } from 'react';
// You can import supported modules from npm
import { Card } from 'react-native-paper';

export default function App() {
  const [sayac, setSayac] = useState(0);

  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>{sayac}</Text> 

      <Text style={styles.status}>
        {sayac > 0 ? 'Pozitif' : sayac < 0 ? 'Negatif' : 'Sıfır'}
      </Text>

      <View style={styles.btn}>
        <Button title="Arttır" onPress={() => setSayac(sayac + 1)} />
      </View>

      <View style={styles.btn}>
        <Button title="Azalt" onPress={() => setSayac(sayac - 1)} />
      </View>

      <View style={styles.btn}>
        <Button title="Sıfırla" onPress={() => setSayac(0)} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },

  btn: {
    marginTop: 10,
    width: '70%',
    marginEnd: '15%',
    marginStart: '15%',
  },

  paragraph: {
    flex: 0,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },

  status: {
    fontSize: 16,
    textAlign: 'center',
    marginVertical: 10,
  },
});
