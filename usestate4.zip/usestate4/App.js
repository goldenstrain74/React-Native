import React, { useState, useEffect } from 'react';
import { Text, View, Button, StyleSheet } from 'react-native';


const Counter = () => {
  const [count, setCount] = useState(0);
  const [amount, setAmount] = useState(1);

  
  useEffect(() => {
    
    const interval = setInterval(() => {
      setCount(prevCount => prevCount + 1); 
    }, 1000); 

    return () => clearInterval(interval);
  }, []); 

  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>Sayaç: {count}</Text>
      <Button
        style={styles.btn}
        title="Artır"
        onPress={() => setCount(count + amount)}
      />
      <Button
        style={styles.btn}
        title="Sıfırla"
        onPress={() => setCount(0)}
      />

      <Text style={styles.paragraph}>Artış Miktarı: {amount}</Text>
      <Button title="1" onPress={() => setAmount(1)} />
      <Button title="5" onPress={() => setAmount(5)} />
    </View>
  );
};

export default function App() {
  const [visible, setVisible] = useState(false);

  return (
    <View style={styles.container}>
      <Button title="Göster/Gizle" onPress={() => setVisible(!visible)} />
      
      {visible && <Counter />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: '450',
    textAlign: 'center',
  },
  btn: {
    margin: 10,
  },
});
