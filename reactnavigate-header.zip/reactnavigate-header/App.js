import  React, {useState, useLayoutEffect} from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Text, Image,Button } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import UserDetail from './src/screens/UserDetail';
import HomeScreen from './src/screens/Home';
import UsersScreen from './src/screens/Users';

const Stack = createNativeStackNavigator();
function HeaderLogo() {
  return (
     
    <Image
    style={{width:90,height:40,marginLeft:'80%'}}
    source={require("./582996-lionel-messi.jpg")}
    />
    
  );
}
function App() {
  return (
    <NavigationContainer>



      <Stack.Navigator initialRouteName="Home" screenOptions={{headerStyle:{
              backgroundColor:"#f4511e",
              
            },
            headerTintColor:"#fff",
            headerTintStyle:{
              fontWeight:"bold",
            },}}>
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={
            { 
             title: 'anasayfa',
             headerTitle:(props) => <HeaderLogo{...props}/>,
             headerLeft: () => (
          <Button title="sol btn" onPress={() => alert('Sol Butona basıldı !')}></Button>),}  } />

        <Stack.Screen name="Users" component={UsersScreen}options={{title: 'Kullanıcılar', headerRight: () => (
          <Button title="Bilgi" onPress={() => alert('bilgiler!')}></Button>), }  }/>

       <Stack.Screen name="UserDetail" component={UserDetail} options={({ route }) => ({title:route.params.name}) } />

      </Stack.Navigator>
     
    </NavigationContainer>
  );
}


export default App;
