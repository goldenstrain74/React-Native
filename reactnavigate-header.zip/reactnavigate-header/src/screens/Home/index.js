import React, {useLayoutEffect, useState} from "react";
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import {View,Text,Button} from "react-native"
function HomeScreen({navigation}) {

 const [count, setCount] = React.useState(0);

  React.useEffect(() => {
    // Use `setOptions` to update the button that we previously specified
    // Now the button includes an `onPress` handler to update the count
    navigation.setOptions({
      headerRight: () => (
        <Button onPress={() => setCount((c) => c + 1)} title="arttır" />
      ),
    });
  }, [navigation]);

  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
      <Text> {count} </Text>
      <Text>Ana Sayfa</Text>
      <Button title="Kullanıcılara Git" onPress={()=>navigation.navigate("Users")}/>

    

    </View>
  );
}
export default HomeScreen;
