import React from "react";
import {View,Text,Button,FlatList} from "react-native"
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
 import Item from "./Item";
 const data=[
   {
     id:1,
     name:"Ahmet"
   },
    {
     id:2,
     name:"Ayşe"
   },
    {
     id:3,
     name:"Fatma"
   },
 ]
const UsersScreen = () => {
  return(
    <FlatList
    data={data}
    keyExtractor={(item)=>item.id}
    renderItem={({item})=><Item item={item}/>}/>
  );
};
export default UsersScreen;