import React from "react"
import {View,Text,StyleSheet,Button ,TouchableOpacity} from "react-native"
import {useNavigation} from "@react-navigation/native"
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

const Item =({item})=>{
  const navigation=useNavigation();
  console.log("item",item);
  return(
    <View style={styles.container}>
    <TouchableOpacity onPress={()=>navigation.navigate("UserDetail",item)}>
    <Text style={styles.text}>{item.name}</Text>
    
    </TouchableOpacity>
    </View>
  )
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#D8D8D8',
    padding: 8,
    borderBottomWidth:1,
  },
  text: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
export default Item;