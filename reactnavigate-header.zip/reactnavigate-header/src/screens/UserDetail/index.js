import {View,Text,StyleSheet, Button} from "react-native";
import React from "react"; 
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

const UserDetail=({route, navigation })=>{
  const data = route.params;
  console.log("data",data);

  return(
    <View>
    <Text style={styles.text}>UserDetail</Text>
    <Text style={styles.text}>{JSON.stringify(data,null,2)}</Text>
    <Button title="Başlığı güncelle" onPress={() => navigation.setOptions({title:"Günecellenmiş başlık"})}
    />
    </View>
  )
};
const styles = StyleSheet.create({

  text: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
  },
});
export default UserDetail;