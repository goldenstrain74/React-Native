import React, { useState } from 'react';
import { Text, View, StyleSheet, FlatList, Button } from 'react-native';

export default function App() {
  const [users, setUsers] = useState([
    { id: 1, helele: 'Ahmet Esat' },
    { id: 2, helele: 'Alper' }
  ]);

  const handlePress = () => {
    setUsers((prev) => [
      ...prev,
      {
        id: Math.floor(Math.random() * 1000),
        helele: Math.floor(Math.random() * 1000).toString()
      }
    ]);
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={users}
        keyExtractor={(item) => item.id} 
        renderItem={({item} ) => ( 
          <View style={styles.item}>
            <Text style={styles.paragraph}>{item.helele}</Text>
          </View>
        )}
      />
      <Button title="tıkla" onPress={handlePress} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ccc',
    padding: 8,
  },
  paragraph: {
    marginTop:3,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'black',
  },
  item: {
    padding: 5,
    marginTop: 10,
    backgroundColor: 'whitesmoke',
    width: '100%',
    height: 40,
  },
});
