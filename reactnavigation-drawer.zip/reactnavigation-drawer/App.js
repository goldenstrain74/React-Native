import React, {useState,useEffect} from 'react';
import { View, Text, Button, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator, DrawerContentScrollView, DrawerItem } from '@react-navigation/drawer';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';



function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Ana Sayfa</Text>
      <Button title="Kullanıcılar Ekranına Git" onPress={() => navigation.navigate('Kullanıcılar')} />
    </View>
  );
}





function UsersScreen({ navigation }) {
  const renderItem = ({ item }) => (
  
    
    <TouchableOpacity
      style={styles.item}
      onPress={() => navigation.navigate('UserDetail', item)}
    >
      <Text style={styles.itemText}>{item.name}</Text>
    </TouchableOpacity>
  );

  const [users,setUsers] = useState([])
  const [loading,setLoading] = useState(true)


  useEffect(()=>{
    fetch("https://jsonplaceholder.typicode.com/users")
    .then((res) => res.json() )
    .then((data) => setUsers(data) )
    .finally(()=> setLoading(false));
  },[])

  return (
    <View style={styles.container}>
      <Text> Kullanıcı bilgileri için tıklayın  </Text>



      <FlatList
        data={users}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
      />
    </View>
  );
}

function UserDetail({ route }) {
  const item = route.params;
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Kullanıcı Detayları</Text>
      <Text style={styles.detail}>İsim: {item.name}</Text>
      <Text style={styles.detail}>No: {item.id}</Text>
      <Text style={styles.detail}>e-mail: {item.email}</Text>
    
    </View>
  );
}

const UsersStack = createNativeStackNavigator();
function UsersStackNavigator() {
  return (
    <UsersStack.Navigator>
      <UsersStack.Screen
        name="UsersScreen"
        component={UsersScreen}
        options={{ title: 'Kullanıcılar' }}
      />
      <UsersStack.Screen
        name="UserDetail"
        component={UserDetail}
        options={{ title: 'Kullanıcı Bilgileri' }}
      />
    </UsersStack.Navigator>
  );
}

const Tab = createBottomTabNavigator();
function BottomTabs() {
  return (
    <Tab.Navigator>
      <Tab.Screen
        name="Ana Sayfa"
        component={HomeScreen}
        options={{ headerShown: false }}
      />
      <Tab.Screen
        name="Kullanıcılar"
        component={UsersStackNavigator}
        options={{ headerShown: false }}
      />
    </Tab.Navigator>
  );
}

function CustomDrawerContent(props) {
  return (
    <DrawerContentScrollView {...props}>
      <DrawerItem
        label="Ana Sayfa"
        onPress={() =>
          props.navigation.navigate('Main', { screen: 'Ana Sayfa' })
        }
      />
      <DrawerItem
        label="Kullanıcılar"
        onPress={() =>
          props.navigation.navigate('Main', { screen: 'Kullanıcılar' })
        }
      />
    </DrawerContentScrollView>
  );
}

const Drawer = createDrawerNavigator();
function DrawerNavigator() {
  return (
    <Drawer.Navigator
      drawerContent={(props) => <CustomDrawerContent {...props} />}
      screenOptions={({ navigation }) => ({
        headerTitle: 'Öğrenci Sistemi',
        headerTitleAlign: 'center',
        headerLeft: () => (
          <TouchableOpacity onPress={() => navigation.toggleDrawer()}>
            <Text style={{ marginLeft: 15, fontSize: 18 }}>☰</Text>
          </TouchableOpacity>
        ),
      })}
    >
      <Drawer.Screen
        name="Main"
        component={BottomTabs}
        // Drawer ekranı için header görünümü aktif:
        options={{ headerShown: true }}
      />
    </Drawer.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <DrawerNavigator />
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    backgroundColor: '#f9f9f9',
  },
  header: {
    fontSize: 24,
    marginBottom: 16,
  },
  item: {
    padding: 16,
    marginVertical: 8,
    backgroundColor: '#ddd',
    width: '100%',
    borderRadius: 8,
  },
  itemText: {
    fontSize: 18,
    textAlign:'center',
  },
  detail: {
    fontSize: 18,
    marginVertical: 4,
  },
});