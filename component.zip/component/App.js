import { props,Text, View, StyleSheet } from 'react-native';

import Title from './components/C_Title'



function Baslik(props) {
return ( 
  <View > 
    <Text  style= {[styles.baslik, {color: props.color},{fontSize: props.fontSize}]}> {props.numberOfLines} -{props.text}</Text> 
  </View>
  
  );

}







export default function App() {
  return (
    <View style = {styles.container}>
    
    <Title/>
    <Title/>
    <Title/>
    

    
    <Baslik
     numberOfLines={1}
     color="yellow" 
     text="Fener"

    />
    
    <Baslik
    numberOfLines={2}
     color="darkblue" 
     text="Bahçe"

    />

    <Baslik
    numberOfLines={3}
     color="green" 
     text="Spor"

    />

    <Baslik
    numberOfLines={4}
     color="white" 
     text="Kulübü"

    />

    
      

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ccc',
    padding: 8,
  },
 

  baslik: {
    textAlign: 'center',
    fontSize: 40,
    fontWeight: '700',
  }
});
