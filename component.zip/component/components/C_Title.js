import {props,StyleSheet, View, Text} from 'react-native'


const Title = (props) => {
return(
  <View> 
    <Text style={styles.baslik}> Şampiyon </Text>
  </View>
);

};

const styles = StyleSheet.create({
  baslik: {
    textAlign: 'center',
    fontSize: 30,
    fontWeight: '700',
  }
});

export default Title;