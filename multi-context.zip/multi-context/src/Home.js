import { View, Text, Button, StyleSheet } from 'react-native';
import React, { useContext } from 'react';
import ThemeContext from './Context/ThemeContext';
import LangContext from './Context/LangContext';

function Home({ navigation }) {
  const { theme, ToggleTheme } = useContext(ThemeContext);
  const { lang, setLang } = useContext(LangContext); 

  return (
    <View style={styles.container}>
      <Text style={styles.h}>Home Screen</Text>
      <Button title="Go to Settings" onPress={() => navigation.navigate('Settings')} />

      <Text style={styles.txt}>Active Theme: {theme}</Text>
      <Button title="Toggle Theme" onPress={ToggleTheme} />

      <Text>Active Language: {lang}</Text>

      <View style={styles.toggleLang}>
        <Button title="tr-TR" onPress={() => setLang('tr-TR')} />
        <Button title="en-US" onPress={() => setLang('en-US')} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  h: {
    fontSize: 25,
    fontWeight: '500', // Düzeltilmiş fontWeight
    textAlign: 'center',
    marginBottom: 30,
  },
  txt: {
    fontSize: 18,
    fontWeight: '400', // Düzeltilmiş fontWeight
    textAlign: 'center',
    marginBottom: 10,
    marginTop: 15,
  },
  toggleLang: {
    alignItems: 'center',
    justifyContent: 'space-around',
    flexDirection: 'row',
    padding: 10,
    width: 140,
    height: 50,
  },
});

export default Home;