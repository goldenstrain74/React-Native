import Route from './src/Route';
import { ThemeContextProvider } from './src/Context/ThemeContext'; 
import { LangContextProvider } from './src/Context/LangContext'

export default function App() {
  return (

    <LangContextProvider> 
      <ThemeContextProvider>
        <Route />
      </ThemeContextProvider>
    </LangContextProvider>
    

  );
}