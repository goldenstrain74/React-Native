import { Text, View, StyleSheet } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';


import * as React from 'react';
import { createStaticNavigation } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

function DetailsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>Details Screen </Text>
    </View>
  );
}

function HomeScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>Home Screen </Text>
    </View>
  );
}

const RootStack = createNativeStackNavigator({
  initialRouteName: 'Home', //buradan açılan sayfanın hangisi olacağını değiştirebiliyoruz
  screenOptions: {
    headerStyle: { backgroundColor: 'lime' },
  },
  screens: {
    Home: {
      screen: HomeScreen,
      options: {
        title: 'Home',
      },
    },
    Details: DetailsScreen,
  },
});

const Navigation = createStaticNavigation(RootStack);

export default function App() {
  return <Navigation />;
}


const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    fontSize: 25,
    fontWeight: 500,
    textAlign: 'center',
  },
});
