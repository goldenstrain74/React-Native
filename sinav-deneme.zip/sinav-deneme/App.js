import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Button,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  Image,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

// -----------------------
// Özel Header Bileşeni
// Tüm ekranların navbar’ında tek bir kere "Borusan" yazısı ve logo gösterilir.
function CustomHeaderTitle() {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
      <Text style={{ fontSize: 20, fontWeight: 'bold' }}>Borusan</Text>
      <Image
        source={require('./assets/snack-icon.png')}
        style={{ width: 40, height: 40, marginLeft: 10 }}
      />
    </View>
  );
}

// -----------------------
// 1. Giriş Ekranı (LoginScreen)
function LoginScreen({ navigation }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const handleLogin = () => {
    // Basit doğrulama: kullanıcı adı "user" ve şifre "1234" olmalı
    if (username === 'user' && password === '1234') {
      navigation.replace('MainTabs');
    } else {
      setErrorMsg('Kullanıcı adı veya şifre hatalı!');
    }
  };

  return (
    <View style={styles.container}>
      <Image
        source={require('./assets/snack-icon.png')}
        style={{ width: 150, height: 150, marginBottom: 20 }}
      />
      <TextInput
        style={styles.input}
        placeholder="Kullanıcı Adı"
        value={username}
        onChangeText={setUsername}
      />
      <TextInput
        style={styles.input}
        placeholder="Şifre"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      {errorMsg ? <Text style={styles.error}>{errorMsg}</Text> : null}
      <Button title="Giriş Yap" onPress={handleLogin} />
    </View>
  );
}

// -----------------------
// 2. Ana Sayfa (HomeScreen)
// "Hoş Geldiniz" yazısı ve basılabilir bir resim bulunur.
// Resme dokununca Tab Navigator'daki "Ürünler" sekmesine geçiş olur.
function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Hoş Geldiniz</Text>
      <TouchableOpacity onPress={() => navigation.navigate('Ürünler')}>
        <Image
          source={require('./assets/snack-icon.png')}
          style={{ width: 200, height: 200 }}
        />
      </TouchableOpacity>
    </View>
  );
}

// -----------------------
// 3. Ürün Kategorileri Ekranı (ProductCategoriesScreen)
// FlatList ile 3 kategori listelenir: Bilgisayar, Telefon, Kamera.
function ProductCategoriesScreen({ navigation }) {
  const categories = [
    { id: '1', name: 'Bilgisayar', image: require('./assets/snack-icon.png') },
    { id: '2', name: 'Telefon', image: require('./assets/snack-icon.png') },
    { id: '3', name: 'Kamera', image: require('./assets/snack-icon.png') },
  ];

  const renderItem = ({ item, index }) => (
    <TouchableOpacity
      style={[styles.item, { backgroundColor: index % 2 === 0 ? "#caf" : "#fac" }]}
      onPress={() => navigation.navigate('CategoryItems', { category: item })}
    >
      <Image
        source={require('./assets/snack-icon.png')}
        style={{ width: 50, height: 50, marginRight: 10 }}
      />
      <Text style={styles.text}>{item.name}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <FlatList data={categories} keyExtractor={(item) => item.id} renderItem={renderItem} />
    </View>
  );
}

// -----------------------
// 4. Kategori Ürünleri Ekranı (CategoryItemsScreen)
// Seçilen kategoriye göre; örneğin:
//   - "Bilgisayar" için: Apple, Dell, HP
//   - "Telefon" için: Samsung, iPhone, Xiaomi
//   - "Kamera" için: Canon, Nikon, Sony
function CategoryItemsScreen({ route, navigation }) {
  const { category } = route.params;
  let items = [];
  if (category.name === 'Bilgisayar') {
    items = [
      {
        id: '1',
        name: 'Apple',
        image: require('./assets/snack-icon.png'),
        price: '$2000',
        processor: 'M1',
        ram: '8GB',
        storage: '256GB',
      },
      {
        id: '2',
        name: 'Dell',
        image: require('./assets/snack-icon.png'),
        price: '$1500',
        processor: 'Intel i7',
        ram: '16GB',
        storage: '512GB',
      },
      {
        id: '3',
        name: 'HP',
        image: require('./assets/snack-icon.png'),
        price: '$1400',
        processor: 'Intel i5',
        ram: '8GB',
        storage: '256GB',
      },
    ];
  } else if (category.name === 'Telefon') {
    items = [
      {
        id: '1',
        name: 'Samsung',
        image: require('./assets/snack-icon.png'),
        price: '$800',
        processor: 'Exynos 2100',
        ram: '8GB',
        storage: '128GB',
      },
      {
        id: '2',
        name: 'iPhone',
        image: require('./assets/snack-icon.png'),
        price: '$1200',
        processor: 'A14 Bionic',
        ram: '4GB',
        storage: '64GB',
      },
      {
        id: '3',
        name: 'Xiaomi',
        image: require('./assets/snack-icon.png'),
        price: '$500',
        processor: 'Snapdragon 865',
        ram: '6GB',
        storage: '128GB',
      },
    ];
  } else if (category.name === 'Kamera') {
    items = [
      {
        id: '1',
        name: 'Canon',
        image: require('./assets/snack-icon.png'),
        price: '$900',
        processor: 'Canon Processor',
        ram: 'N/A',
        storage: 'N/A',
      },
      {
        id: '2',
        name: 'Nikon',
        image: require('./assets/snack-icon.png'),
        price: '$850',
        processor: 'Nikon EXPEED',
        ram: 'N/A',
        storage: 'N/A',
      },
      {
        id: '3',
        name: 'Sony',
        image: require('./assets/snack-icon.png'),
        price: '$950',
        processor: 'Sony BIONZ',
        ram: 'N/A',
        storage: 'N/A',
      },
    ];
  }

  const renderItem = ({ item, index }) => (
    <TouchableOpacity
      style={[styles.item, { backgroundColor: index % 2 === 0 ? "#fac" : "#caf" }]}
      onPress={() => navigation.navigate('Detail', { item })}
    >
      <Image
        source={require('./assets/snack-icon.png')}
        style={{ width: 50, height: 50, marginRight: 10 }}
      />
      <Text style={styles.text}>{item.name}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.header}>{category.name} Markaları</Text>
      <FlatList data={items} keyExtractor={(item) => item.id} renderItem={renderItem} />
    </View>
  );
}

// -----------------------
// 5. Ürün Detayları Ekranı (DetailScreen)
// Seçilen markanın detaylarını (fiyat, işlemci, RAM, depolama ve fotoğrafı) gösterir.
function DetailScreen({ route }) {
  const { item } = route.params;
  return (
    <View style={styles.container}>
      <Text style={styles.header}>{item.name} Detayları</Text>
      <Image
        source={require('./assets/snack-icon.png')}
        style={{ width: 150, height: 150, marginBottom: 20 }}
      />
      <Text style={styles.detail}>Fiyat: {item.price}</Text>
      <Text style={styles.detail}>İşlemci: {item.processor}</Text>
      <Text style={styles.detail}>RAM: {item.ram}</Text>
      <Text style={styles.detail}>Depolama: {item.storage}</Text>
    </View>
  );
}

// -----------------------
// Tab Navigator: "Ana Sayfa" ve "Ürünler"
// Alt tablarda header gizlenecek; ana header yalnızca Root Stack Navigator'da gösterilecek.
const Tab = createBottomTabNavigator();
function MainTabs() {
  return (
    <Tab.Navigator screenOptions={{ headerShown: false }}>
      <Tab.Screen name="Ana Sayfa" component={HomeScreen} />
      <Tab.Screen name="Ürünler" component={ProductCategoriesScreen} />
    </Tab.Navigator>
  );
}

// -----------------------
// Root Stack Navigator
// Giriş, MainTabs, CategoryItems ve Detail ekranlarını kapsar.
// Tüm ekranlarda tek bir header, CustomHeaderTitle ile gösterilir.
const Stack = createNativeStackNavigator();
function RootStackNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerTitle: () => <CustomHeaderTitle />,
        headerTitleAlign: 'center',
      }}
    >
      <Stack.Screen name="Login" component={LoginScreen} options={{ headerShown: false }} />
      <Stack.Screen name="MainTabs" component={MainTabs} options={{ title: 'Ana Sayfa' }} />
      <Stack.Screen
        name="CategoryItems"
        component={CategoryItemsScreen}
        options={({ route }) => ({ title: route.params.category.name })}
      />
      <Stack.Screen
        name="Detail"
        component={DetailScreen}
        options={({ route }) => ({ title: route.params.item.name })}
      />
    </Stack.Navigator>
  );
}

// -----------------------
// Uygulama Giriş Noktası
export default function App() {
  return (
    <NavigationContainer>
      <RootStackNavigator />
    </NavigationContainer>
  );
}

// -----------------------
// Stil Tanımlamaları
const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    backgroundColor: '#f9f9f9',
  },
  header: {
    fontSize: 24,
    marginBottom: 16,
  },
  input: {
    width: '80%',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
  },
  error: {
    color: 'red',
    marginBottom: 10,
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    marginVertical: 8,
    borderRadius: 8,
    width: '90%',
  },
  text: {
    fontSize: 18,
  },
  detail: {
    fontSize: 18,
    marginVertical: 4,
  },
});