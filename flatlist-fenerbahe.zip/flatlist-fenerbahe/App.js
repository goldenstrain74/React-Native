import React from 'react';
import { View, Text, FlatList, StyleSheet, Image, ScrollView } from 'react-native';

const players = [
  { id: '1', name: 'Enner Valencia', position: 'Forvet' },
  { id: '2', name: 'Mesut Özil', position: 'Orta Saha' },
  { id: '3', name: 'Joshua King', position: 'Forvet' },
  { id: '4', name: 'Serdar Aziz', position: 'Defans' },
  { id: '5', name: 'Dimitris Pelkas', position: 'Orta Saha' },
];

const scores = [
  { id: '1', match: 'Fenerbahçe vs Galatasaray', score: '3-1' },
  { id: '2', match: 'Fenerbahçe vs Beşiktaş', score: '2-2' },
  { id: '3', match: 'Fenerbahçe vs Trabzonspor', score: '1-0' },
];

const legends = [
  { id: '1', name: 'Alex de Souza', role: 'Efsane Futbolcu' },
  { id: '2', name: 'Hasan Ali Kaldırım', role: 'Efsane Futbolcu' },
  { id: '3', name: 'Roberto Carlos', role: 'Efsane Futbolcu' },
];

const trophies = [
  { id: '1', title: 'Süper Lig Şampiyonluğu', year: '28 kere' },
  { id: '2', title: 'Türkiye Kupası', year: '7 kere' },
  { id: '3', title: 'Türkiye Süper Kupa', year: '9 kere' },
  { id: '4', title: 'Balkanlar Kupası', year: '1 kere' },
];

const App = () => {
  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Image
          source={{ uri: 'https://upload.wikimedia.org/wikipedia/commons/0/05/Fenerbahçe_Sport_Club_logo_2012.svg' }}
          style={styles.logo}
        />
        <Text style={styles.title}>Fenerbahçe Spor Kulübü</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Fenerbahçe Kadrosu (2025)</Text>
        <FlatList
          data={players}
          renderItem={({ item }) => (
            <View style={styles.playerItem}>
              <Text style={styles.playerName}>{item.name}</Text>
              <Text style={styles.playerPosition}>{item.position}</Text>
            </View>
          )}
          keyExtractor={item => item.id}
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Son Maçlar</Text>
        <FlatList
          data={scores}
          renderItem={({ item }) => (
            <View style={styles.matchItem}>
              <Text style={styles.matchText}>{item.match}</Text>
              <Text style={styles.matchScore}>{item.score}</Text>
            </View>
          )}
          keyExtractor={item => item.id}
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Fenerbahçe Efsaneleri</Text>
        <FlatList
          data={legends}
          renderItem={({ item }) => (
            <View style={styles.legendItem}>
              <Text style={styles.legendName}>{item.name}</Text>
              <Text style={styles.legendRole}>{item.role}</Text>
            </View>
          )}
          keyExtractor={item => item.id}
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Kazandığı Kupalar</Text>
        <FlatList
          data={trophies}
          renderItem={({ item }) => (
            <View style={styles.trophyItem}>
              <Text style={styles.trophyTitle}>{item.title} ({item.year})</Text>
            </View>
          )}
          keyExtractor={item => item.id}
        />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    backgroundColor: '#F4C300',
    padding: 20,
    alignItems: 'center',
  },
  logo: {
    width: 100,
    height: 100,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#004C97',
    marginTop: 10,
  },
  section: {
    marginTop: 20,
    padding: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#004C97',
  },
  playerItem: {
    marginVertical: 10,
  },
  playerName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  playerPosition: {
    fontSize: 16,
    color: '#555',
  },
  matchItem: {
    marginVertical: 10,
  },
  matchText: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  matchScore: {
    fontSize: 16,
    color: '#555',
  },
  legendItem: {
    marginVertical: 10,
  },
  legendName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  legendRole: {
    fontSize: 16,
    color: '#555',
  },
  trophyItem: {
    marginVertical: 10,
  },
  trophyTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default App;

