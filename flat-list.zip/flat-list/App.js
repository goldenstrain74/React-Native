import { Text, View, StyleSheet, FlatList, TouchableOpacity,  } from 'react-native';
import React, { useState } from 'react';




export default function App() {
 

  const DATA = [

{id:"1", sinif:"11/A", ad:"Ahmet Esat", soyad:"Altunsoy"},
{id:"4", sinif:"11/A", ad:"Alper", soyad:"Kavak"},
{id:"2", sinif:"11-/A", ad:"Beritus", soyad:"Yaşar"},
{id:"999", sinif:"11/J", ad:"Samet", soyad:"Alp"},

];
  const [data, setData] = useState(DATA);
const renderitem = ({item}) => (

  <View style={styles.item}>  
      <TouchableOpacity>
        <Text style={styles.title}>{item.id} - {item.sinif} - {item.ad} {item.soyad}</Text>
      </TouchableOpacity>
  </View>

);
  
  
  return (
    <View style={styles.container}>

     <FlatList
    
     
     data={data}
     renderItem={renderitem}
     keyExtractor={item => item.id} 
     contentContainerStyle={styles.flatList}

     />

    </View>
  );
}

const styles = StyleSheet.create({
container: {
    marginTop:30,
    flex: 1,
    padding: 20, 
  },

  item: {
    marginTop:10,
    padding: 20,
    backgroundColor: 'skyblue', 
    borderRadius: 5, 
  },
  title: {
    fontSize: 18,
  },



});
