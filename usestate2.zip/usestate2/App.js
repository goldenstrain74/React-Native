import React, {useState} from 'react'
import { Text, View, StyleSheet,Button } from 'react-native';


// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  const [user,setUser] = useState({id:1, name:"Ahmet Esat", surname:'Altunsoy'});
  function handlePress() {
    setUser({...user, id:2,name:"Ahmet Bersis",surname:"Yaşar"})
  }

  return (
    
    <View style={styles.container}>
      <Text style={styles.paragraph}> No:{user.id} </Text>
      <Text style={styles.paragraph}> Ad:{user.name} </Text>
      <Text style={styles.paragraph}> Soyad:{user.surname} </Text>

      <Button title="değiştir" onPress={()=>handlePress()}/> 
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems:'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 5,
    fontSize: 20,
    fontWeight: 400,
    textAlign: 'center',
  },
});
