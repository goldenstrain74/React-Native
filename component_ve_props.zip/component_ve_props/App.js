import { props,Text, View, StyleSheet } from 'react-native';


const Title = (props) => {
console.log(props)
return(
  <View> 
   <Text> {props.text} </Text>
  </View>
);

};


function Baslik(props) {
return ( 
  <View > 
    <Text  style= {[styles.baslik, {color: props.color}]}> {props.text}</Text> 
  </View>
  
  );

 

};


export default function App() {
  return (
    <View style = {styles.container}>
    <Baslik
    
     color="red" 
     text="merhaba dünya"
    />

  

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },

  baslik: {
    textAlign: 'center',
    fontSize: 40,
    fontWeight: '700',
  }
});
