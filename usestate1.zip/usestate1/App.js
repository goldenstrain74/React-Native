import React, {useState} from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';


export default function App() {

  const [name,setName]=useState('Ahmet');
  const [no,setNo]=useState(1);
  const [isVisible, setIsVisible]=useState(false);

  return (
    <View style={styles.container}>
      
    <Button title={isVisible? "Gizle":"Göster"}  onPress={()=> setIsVisible(!isVisible)} />

    {isVisible && (

      <>
        <Text style={styles.yazi}> Ad: {name} </Text>
        <Text style={styles.yazi}> Numara: {no} </Text>

        <Button title="isim değiştir" onPress={()=>  setName(name==="Ahmet"? "Esat":"Ahmet")} />
        <Button title="numara değiştir" onPress={()=>  setNo(no===1 ? 2:1)} /> 
      </>
    )}

    

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems:'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },

yazi: {
    fontSize:20,
}

});
