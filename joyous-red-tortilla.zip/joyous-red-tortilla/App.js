import React,{useState} from 'react';
import { Text,View, Button,StyleSheet } from 'react-native';



const Counter = ()=> {
  const [count,setCount] = useState(0);
  const [amounth,setAmounth] = useState(1);
  const [visible,setVisible] = useState(true);
  return(
    
    <View style={styles.container}> 
      <Text style={styles.paragraph}> Sayaç: {count} </Text>
      <Button style={styles.btn} title="arttır" onPress={()=> setCount(count+amounth)}/>
      <Button style={styles.btn} title="sıfırla" onPress={()=> setCount(count-count)} />

      <Text style={styles.paragraph}> Artış Miktarı: {amounth} </Text>
      <Button title="1" onPress={()=> setAmounth()} />
      <Button title="5" onPress={()=> setAmounth()} />
    </View>
  )

}



export default function App() {
  return (
    <View style={styles.container}>
      <Counter/>
    </View>
  );
}




const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems:'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },

  btn: {
    
  },
});
